Mini DX3/DX4/DX4B Software

Files:
- setup.exe (main installer)
- MiniDX3/MiniDX3.exe (standalone app)
- MiniDX3/usb_Driver.exe (USB driver)
- User manuals included as PDFs

Support: https://avidityid.com
