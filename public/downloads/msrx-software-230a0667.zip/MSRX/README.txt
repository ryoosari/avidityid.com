MSRX Software for MSR605X / MSR X6 / MSR X6BT
=============================================

Windows:
  - MSRX v2017 - Setup.exe  (recommended, latest)
  - MSRX v2015a - Setup.exe (older fallback version)
  - MSRX v2017.rar          (alternative archive format)

Mac:
  - See /Mac folder for macOS application

Requirements:
  - Windows 7+ or macOS 10.12+
  - MSR605X, MSR X6, or MSR X6BT hardware
  - USB port

Support: https://avidityid.com
