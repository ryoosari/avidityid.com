MSR009 / MSRV009 Software

Files:
- InitPwd_for_MSR009_MSRV009.rar (password initialization tool)
- Read Me.txt (instructions)

Support: https://avidityid.com
