MSR90 Magnetic Card Reader Software

Files:
- MSR90-20151116234618492.zip (Windows software)

Support: https://avidityid.com
