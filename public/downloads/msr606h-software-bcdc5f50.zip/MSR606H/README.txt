MSR606H Magnetic Card Reader/Writer Software

Files:
- MSR606H/setup.exe (Windows installer)
- MSR606H-20140604034858907.zip (alternative archive)

Support: https://avidityid.com
