MCR200 Magnetic Card Reader/Writer Software

Files:
- MCR200_Setup.rar (Windows installer, archived)
- MCR200-Windows10.zip (Windows 10 compatible)

Support: https://avidityid.com
